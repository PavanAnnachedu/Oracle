"""
CLI script to sign in to Microsoft Fabric using Microsoft Organization (Work or School)
interactive browser sign-in and cache the token persistently in Windows Credential Store.
"""

import sys
import base64
import json
import os
from azure.identity import InteractiveBrowserCredential, TokenCachePersistenceOptions

FABRIC_SCOPE = "https://api.fabric.microsoft.com/.default"


def decode_token_claims(token_str: str) -> dict:
    try:
        parts = token_str.split(".")
        if len(parts) >= 2:
            payload = parts[1]
            rem = len(payload) % 4
            if rem > 0:
                payload += "=" * (4 - rem)
            return json.loads(base64.urlsafe_b64decode(payload.encode("utf-8")))
    except Exception:
        pass
    return {}


def main():
    tenant = os.getenv("AZURE_TENANT_ID") or "organizations"
    print("=" * 68, flush=True)
    print(" MICROSOFT FABRIC - ORGANIZATION ACCOUNT (WORK/SCHOOL) SIGN-IN", flush=True)
    print(f" Authority Tenant: {tenant}", flush=True)
    print("=" * 68, flush=True)
    print("Opening default web browser for organization sign-in...", flush=True)
    print("Please pick your Microsoft Organization (Work or School) account.\n", flush=True)

    cache_opts = None
    try:
        cache_opts = TokenCachePersistenceOptions()
    except Exception as e:
        print(f"Note: Persistent cache setup ({e}), falling back to memory.", flush=True)

    kwargs = {
        "tenant_id": tenant,
        "prompt": "select_account",
    }
    if cache_opts:
        kwargs["cache_persistence_options"] = cache_opts

    cred = InteractiveBrowserCredential(**kwargs)

    try:
        token_obj = cred.get_token(FABRIC_SCOPE)
        claims = decode_token_claims(token_obj.token)
        name = claims.get("name") or claims.get("unique_name") or "Organization User"
        email = claims.get("preferred_username") or claims.get("upn") or claims.get("email") or ""
        tid = claims.get("tid") or ""
        print("\n" + "=" * 68, flush=True)
        print(" LOGIN SUCCESSFUL!", flush=True)
        print(f" Signed in as: {name} ({email})", flush=True)
        if tid:
            print(f" Tenant ID:   {tid}", flush=True)
        print(" Credentials cached securely. You can now use Fabric Provisioner.", flush=True)
        print("=" * 68 + "\n", flush=True)
    except Exception as e:
        print(f"\nSign-in failed: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
