# Fabric Workspace Provisioner

Web app that takes a **Fabric capacity ID**, a **workspace name** and a **warehouse name**, then:

1. Creates the workspace — `POST /v1/workspaces`
2. Assigns it to the capacity — `POST /v1/workspaces/{id}/assignToCapacity` (waits until `capacityAssignmentProgress = Completed`)
3. (Optional) Adds a user/group/SP as workspace Admin
4. Creates the warehouse — `POST /v1/workspaces/{id}/warehouses` (polls the long-running operation)

Optional: roll back (delete the workspace) if a later step fails.

## Run

```bash
pip install -r requirements.txt
python app.py             # Starts web app on http://localhost:5000
```

Or authenticate beforehand via terminal:
```bash
python login.py           # Interactive sign-in / device login
```

## Authentication

By default, the application uses **Interactive Browser Sign-In** (`AUTH_MODE=INTERACTIVE`).
- A browser tab opens automatically to authenticate your Microsoft Entra account.
- You can also sign in directly in the web app UI at `http://localhost:5000`.
- Once signed in, credentials are securely cached in Windows Credential Store.
- Because you sign in interactively, **you directly own and administer the created workspace** in Microsoft Fabric.

## Permissions needed

- **User account:** You must have permissions to create Fabric workspaces in your tenant and access the Fabric capacity.
- **Capacity:** Your account must be a **Capacity Admin** or have **Contributor** permission on the capacity.
- The capacity must be **Active** (not paused).

