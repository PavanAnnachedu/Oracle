# Fabric Workspace & MetaData Provisioner

Web application that automates the end-to-end setup of Microsoft Fabric infrastructure and partner metadata:

1. **Creates the workspace** — `POST /v1/workspaces`
2. **Assigns it to a Fabric capacity** — `POST /v1/workspaces/{id}/assignToCapacity` (monitors until `capacityAssignmentProgress = Completed`)
3. **(Recommended) Adds a User / Group as workspace Admin** — `POST /v1/workspaces/{id}/roleAssignments` so human developers can view and manage the workspace in `app.fabric.microsoft.com`
4. **Creates the primary SQL warehouse** — `POST /v1/workspaces/{id}/warehouses` (polls the long-running operation)
5. **Inserts partner records into MetaData Warehouse**:
   - `[Partner].[PartnerMaster]`
   - `[Partner].[ConfigMaster]` with watermark defaults (e.g., `1990-01-01 00:00:00.000000`) derived from `[Partner].[TableDefinition]`
6. **Automatic rollback (optional)**: Cleans up the workspace if any step fails.

---

## Authentication: Azure Entra Service Principal

By default, the application uses **Azure Entra Service Principal** (`AUTH_MODE=SERVICE_PRINCIPAL`) for both:
- **Microsoft Fabric REST API** (workspace creation, capacity assignment, and warehouse provisioning)
- **MetaData Warehouse SQL connection** (inserting records into `[Partner].[PartnerMaster]` and `[Partner].[ConfigMaster]`)

### 1. Web UI Configuration (Recommended) or `.env`

You can enter your Service Principal credentials **directly in the web application UI** when you launch it at `http://localhost:5000`. The UI allows you to test the connection live, view status, and optionally save the credentials to `.env`.

Alternatively, you can pre-configure them in `.env`:

```ini
AUTH_MODE=SERVICE_PRINCIPAL

# Microsoft Entra Directory (Tenant) ID (GUID)
AZURE_TENANT_ID=your-tenant-id-guid

# Azure App Registration Application (Client) ID (GUID)
AZURE_CLIENT_ID=your-client-id-guid

# Client Secret Value
AZURE_CLIENT_SECRET=your-client-secret-value

# MetaData Warehouse SQL Endpoint & Database
METADATA_SQL_ENDPOINT=your-fabric-sql-endpoint.datawarehouse.fabric.microsoft.com
METADATA_DATABASE=WH_MetaData
```

### 2. Required Permissions

1. **Microsoft Fabric Tenant Settings** (Fabric Admin Portal):
   - **Developer settings** &rarr; **Service principals can use Fabric APIs**: Enabled.
   - If restricted to security groups, ensure your Service Principal is a member of that group.
2. **Fabric Capacity Permissions**:
   - The Service Principal must have **Contributor** or **Admin** role on the target Fabric Capacity.
3. **MetaData Warehouse Permissions**:
   - The Service Principal must have access to the MetaData Warehouse:
     - Assign the Service Principal **Admin**, **Contributor**, or **Member** role on the workspace hosting `WH_MetaData`, OR
     - Grant SQL permissions directly in the warehouse:
       ```sql
       CREATE USER [<ServicePrincipal-App-Name-Or-Id>] FROM EXTERNAL PROVIDER;
       ALTER ROLE db_owner ADD MEMBER [<ServicePrincipal-App-Name-Or-Id>];
       ```

---

## Running & Verification

### Install dependencies:
```bash
pip install -r requirements.txt
```

### Test Service Principal connection via CLI:
```bash
python login.py
```
This diagnostic script tests:
1. Fabric API token acquisition & capacity discovery
2. SQL token acquisition
3. MetaData Warehouse connection & querying `[Partner].[TableDefinition]`

### Launch the Web App:
```bash
python app.py
```
Open **`http://localhost:5000`** in your browser. The web app will verify your Service Principal and automatically populate available Fabric capacities. You can also click **Test MetaData DB** to verify SQL connectivity directly from the UI.
