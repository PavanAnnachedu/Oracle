"""
Fabric Provisioner - Web app that:
  1. Authenticates via Microsoft Organization Account OAuth flow
  2. Lists Fabric capacities
  3. Creates a Microsoft Fabric workspace
  4. Assigns it to a Fabric capacity (and waits for completion)
  5. Creates a Warehouse inside the workspace
  6. (Optional) Grants a user/group Admin on the workspace
  7. Inserts metadata records into the MetaData warehouse tables:
     - [Partner].[PartnerMaster]
     - [Partner].[ConfigMaster] (derived from [Partner].[TableDefinition] with watermark 1990)
"""

import os
import re
import time
import base64
import json
import logging
import struct
import urllib.parse
from itertools import chain, repeat
import requests
import msal
try:
    import mssql_python
    HAS_MSSQL_PYTHON = True
except ImportError:
    mssql_python = None
    HAS_MSSQL_PYTHON = False

try:
    import pyodbc
    HAS_PYODBC = True
except ImportError:
    pyodbc = None
    HAS_PYODBC = False
from dotenv import load_dotenv
from flask import Flask, jsonify, render_template, request, redirect, url_for, session, has_request_context
from azure.identity import ClientSecretCredential

load_dotenv()

FABRIC_API = "https://api.fabric.microsoft.com/v1"
FABRIC_SCOPE = "https://api.fabric.microsoft.com/.default"
FABRIC_SCOPES = [FABRIC_SCOPE]
SQL_SCOPE = "https://database.windows.net/.default"
SQL_SCOPES = [SQL_SCOPE]
GRAPH_SCOPE = "https://graph.microsoft.com/.default"
GRAPH_SCOPES = [GRAPH_SCOPE]

GUID_RE = re.compile(r"^[0-9a-fA-F]{8}-([0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}$")
LRO_TIMEOUT_SECONDS = int(os.getenv("LRO_TIMEOUT_SECONDS", "600"))

# Hardcoded Default Credentials & Configuration
DEFAULT_TENANT_ID = "008502d6-3f79-46f0-ab37-9354e3fe80ff"
DEFAULT_CLIENT_ID = "25ad11d7-5885-4f0e-8424-919bf02e04eb"
DEFAULT_CLIENT_SECRET = "SWE8Q~EtZhXJAxLm_mVlLFBSI~It5ljFjID~kbvn"
DEFAULT_CAPACITY_ID = "6268171A-AC1E-4F51-BAE7-23A6BB718CA2"

# Microsoft Organization Account Configuration
CLIENT_ID = (os.getenv("AZURE_CLIENT_ID") or os.getenv("FABRIC_CLIENT_ID") or "").strip() or DEFAULT_CLIENT_ID
TENANT = (os.getenv("AZURE_TENANT_ID") or os.getenv("FABRIC_TENANT_ID") or "").strip() or DEFAULT_TENANT_ID
AUTHORITY = f"https://login.microsoftonline.com/{TENANT}"
CACHE_FILE = os.path.join(os.path.dirname(__file__), ".msal_token_cache.bin")

# MetaData Warehouse Configuration
METADATA_SQL_ENDPOINT = os.getenv(
    "METADATA_SQL_ENDPOINT",
    "2ybikadzh7yenkzxsnkoh7ua74-3umgq6mqhwfuhesadoaslzi5ei.datawarehouse.fabric.microsoft.com",
)
METADATA_DATABASE = os.getenv("METADATA_DATABASE", "WH_MetaData")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("fabric-provisioner")

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "fabric-provisioner-session-secret-2026")

_auth_flows = {}
_token_cache = msal.SerializableTokenCache()


def _update_env_file(tenant_id, client_id, client_secret):
    """Updates AZURE_TENANT_ID, AZURE_CLIENT_ID, and AZURE_CLIENT_SECRET in .env."""
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    lines = []
    keys_found = {"AUTH_MODE": False, "AZURE_TENANT_ID": False, "AZURE_CLIENT_ID": False, "AZURE_CLIENT_SECRET": False}

    if os.path.exists(env_path):
        with open(env_path, "r", encoding="utf-8") as f:
            lines = f.readlines()

    new_lines = []
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("AUTH_MODE="):
            new_lines.append("AUTH_MODE=SERVICE_PRINCIPAL\n")
            keys_found["AUTH_MODE"] = True
        elif stripped.startswith("AZURE_TENANT_ID="):
            new_lines.append(f"AZURE_TENANT_ID={tenant_id}\n")
            keys_found["AZURE_TENANT_ID"] = True
        elif stripped.startswith("AZURE_CLIENT_ID="):
            new_lines.append(f"AZURE_CLIENT_ID={client_id}\n")
            keys_found["AZURE_CLIENT_ID"] = True
        elif stripped.startswith("AZURE_CLIENT_SECRET="):
            new_lines.append(f"AZURE_CLIENT_SECRET={client_secret}\n")
            keys_found["AZURE_CLIENT_SECRET"] = True
        else:
            new_lines.append(line)

    for k, found in keys_found.items():
        if not found:
            if k == "AUTH_MODE":
                new_lines.append("AUTH_MODE=SERVICE_PRINCIPAL\n")
            elif k == "AZURE_TENANT_ID":
                new_lines.append(f"AZURE_TENANT_ID={tenant_id}\n")
            elif k == "AZURE_CLIENT_ID":
                new_lines.append(f"AZURE_CLIENT_ID={client_id}\n")
            elif k == "AZURE_CLIENT_SECRET":
                new_lines.append(f"AZURE_CLIENT_SECRET={client_secret}\n")

    with open(env_path, "w", encoding="utf-8") as f:
        f.writelines(new_lines)


# --------------------------------------------------------------------------- #
# Auth & MSAL Helpers
# --------------------------------------------------------------------------- #
def _load_cache():
    if os.path.exists(CACHE_FILE):
        try:
            with open(CACHE_FILE, "r") as f:
                content = f.read().strip()
                if content:
                    _token_cache.deserialize(content)
        except Exception as e:
            log.warning("Could not load token cache: %s", e)


def _save_cache():
    try:
        data = _token_cache.serialize()
        if data and data.strip() and data.strip() != "{}":
            with open(CACHE_FILE, "w", encoding="utf-8") as f:
                f.write(data)
                f.flush()
                os.fsync(f.fileno())
    except Exception as e:
        log.warning("Could not save token cache: %s", e)


_cache_loaded = False


def _get_msal_app():
    global _cache_loaded
    if not _cache_loaded:
        _load_cache()
        _cache_loaded = True
    return msal.PublicClientApplication(
        CLIENT_ID,
        authority=AUTHORITY,
        token_cache=_token_cache,
    )


def _decode_token_claims(token_str: str) -> dict:
    try:
        parts = token_str.split(".")
        if len(parts) >= 2:
            payload = parts[1]
            rem = len(payload) % 4
            if rem > 0:
                payload += "=" * (4 - rem)
            return json.loads(base64.urlsafe_b64decode(payload.encode("utf-8")))
    except Exception:
        pass
    return {}


_sp_credential = None
_sp_config_key = None


def _get_sp_credentials_from_context():
    """Retrieves SP credentials from session, request context, or environment."""
    if has_request_context():
        sp = session.get("sp_credentials")
        if isinstance(sp, dict):
            t = (sp.get("tenant_id") or "").strip()
            c = (sp.get("client_id") or "").strip()
            s = (sp.get("client_secret") or "").strip()
            if t and c and s:
                return t, c, s

    t = (os.getenv("AZURE_TENANT_ID") or os.getenv("FABRIC_TENANT_ID") or "").strip() or DEFAULT_TENANT_ID
    c = (os.getenv("AZURE_CLIENT_ID") or os.getenv("FABRIC_CLIENT_ID") or "").strip() or DEFAULT_CLIENT_ID
    s = (os.getenv("AZURE_CLIENT_SECRET") or os.getenv("FABRIC_CLIENT_SECRET") or "").strip() or DEFAULT_CLIENT_SECRET
    return t, c, s


def _get_sp_credential(tenant=None, client_id=None, client_secret=None):
    """Returns a cached ClientSecretCredential instance for Service Principal auth."""
    global _sp_credential, _sp_config_key

    if not (tenant and client_id and client_secret):
        tenant, client_id, client_secret = _get_sp_credentials_from_context()

    missing = []
    if not tenant:
        missing.append("Tenant ID (AZURE_TENANT_ID)")
    if not client_id:
        missing.append("Client ID (AZURE_CLIENT_ID)")
    if not client_secret:
        missing.append("Client Secret (AZURE_CLIENT_SECRET)")

    if missing:
        raise FabricError(
            f"Service Principal credentials missing: {', '.join(missing)}. "
            f"Please enter your credentials in the web application or set them in .env.",
            401,
        )

    if tenant.lower() in ("organizations", "common", "consumers"):
        raise FabricError(
            f"Tenant ID cannot be '{tenant}' when using Service Principal. "
            f"It must be your actual Azure Entra Directory (Tenant) ID GUID.",
            400,
        )

    key = (tenant, client_id, client_secret)
    if _sp_credential is None or _sp_config_key != key:
        _sp_credential = ClientSecretCredential(
            tenant_id=tenant,
            client_id=client_id,
            client_secret=client_secret,
        )
        _sp_config_key = key
    return _sp_credential


def _get_access_token():
    auth_mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()

    if auth_mode == "SERVICE_PRINCIPAL":
        cred = _get_sp_credential()
        try:
            return cred.get_token(FABRIC_SCOPE).token
        except Exception as e:
            log.exception("Fabric API Service Principal token acquisition error: %s", e)
            raise FabricError(f"Failed to acquire Fabric API token using Service Principal: {e}", 401) from e

    # Fallback to interactive user token cache if AUTH_MODE == "INTERACTIVE"
    msal_app = _get_msal_app()
    accounts = msal_app.get_accounts()
    if accounts:
        result = msal_app.acquire_token_silent(FABRIC_SCOPES, account=accounts[0])
        if result and "access_token" in result:
            _save_cache()
            return result["access_token"]
    return None


def _get_sql_token():
    auth_mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()

    if auth_mode == "SERVICE_PRINCIPAL":
        cred = _get_sp_credential()
        try:
            return cred.get_token(SQL_SCOPE).token
        except Exception as e:
            log.exception("SQL MetaData Warehouse Service Principal token acquisition error: %s", e)
            raise FabricError(f"Failed to acquire MetaData SQL token using Service Principal: {e}", 401) from e

    # Fallback to interactive user token cache if AUTH_MODE == "INTERACTIVE"
    msal_app = _get_msal_app()
    accounts = msal_app.get_accounts()
    if accounts:
        result = msal_app.acquire_token_silent(SQL_SCOPES, account=accounts[0])
        if result and "access_token" in result:
            _save_cache()
            return result["access_token"]
        log.warning("Silent token acquisition for SQL database returned: %s", result)
    return None


def _get_graph_token():
    auth_mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()

    if auth_mode == "SERVICE_PRINCIPAL":
        cred = _get_sp_credential()
        try:
            return cred.get_token(GRAPH_SCOPE).token
        except Exception as e:
            log.exception("Graph API Service Principal token acquisition error: %s", e)
            raise FabricError(f"Failed to acquire Microsoft Graph token using Service Principal: {e}", 401) from e

    # Fallback to interactive user token cache if AUTH_MODE == "INTERACTIVE"
    msal_app = _get_msal_app()
    accounts = msal_app.get_accounts()
    if accounts:
        result = msal_app.acquire_token_silent(GRAPH_SCOPES, account=accounts[0])
        if result and "access_token" in result:
            _save_cache()
            return result["access_token"]
        log.warning("Silent token acquisition for Microsoft Graph returned: %s", result)
    return None


def resolve_principal_to_guid(identifier: str, default_type: str = "User") -> tuple:
    """
    Resolves an Entra ID principal identifier (which can be a GUID, email, or UPN)
    to a 3-tuple: (object_id_guid, principal_type, display_name).
    """
    ident = (identifier or "").strip()
    if not ident:
        return "", default_type or "User", ""

    # If it is already a valid GUID, return directly
    if GUID_RE.match(ident):
        return ident, default_type or "User", ident

    # If not a GUID, look up the user/group via Microsoft Graph API
    token = _get_graph_token()
    if not token:
        raise FabricError(f"Cannot resolve user '{ident}' because Microsoft Graph token could not be acquired.", 401)

    headers = {"Authorization": f"Bearer {token}"}
    encoded = urllib.parse.quote(ident)

    # 1. Try direct user lookup by userPrincipalName or id: /users/{id_or_upn}
    try:
        r = requests.get(f"https://graph.microsoft.com/v1.0/users/{encoded}", headers=headers, timeout=15)
        if r.status_code == 200:
            user_data = r.json()
            oid = user_data.get("id")
            display_name = user_data.get("displayName") or ident
            return oid, "User", display_name
    except Exception as e:
        log.warning("Direct Graph user lookup failed for %s: %s", ident, e)

    # 2. Try filter query for mail or userPrincipalName
    try:
        filter_q = f"mail eq '{ident}' or userPrincipalName eq '{ident}'"
        r2 = requests.get(
            f"https://graph.microsoft.com/v1.0/users?$filter={urllib.parse.quote(filter_q)}",
            headers=headers,
            timeout=15,
        )
        if r2.status_code == 200:
            items = r2.json().get("value", [])
            if items:
                user_data = items[0]
                return user_data["id"], "User", user_data.get("displayName") or ident
    except Exception as e:
        log.warning("Graph filter user query failed for %s: %s", ident, e)

    # 3. Try filter query for groups
    try:
        filter_g = f"mail eq '{ident}' or displayName eq '{ident}'"
        rg = requests.get(
            f"https://graph.microsoft.com/v1.0/groups?$filter={urllib.parse.quote(filter_g)}",
            headers=headers,
            timeout=15,
        )
        if rg.status_code == 200:
            groups = rg.json().get("value", [])
            if groups:
                group_data = groups[0]
                return group_data["id"], "Group", group_data.get("displayName") or ident
    except Exception as e:
        log.warning("Graph filter group query failed for %s: %s", ident, e)

    raise FabricError(
        f"Could not find any Microsoft Entra user or group matching '{ident}'. "
        f"Please verify the email address or provide their Object ID (GUID) directly.",
        400,
    )



def _headers():
    token = _get_access_token()
    if not token:
        auth_mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()
        if auth_mode == "SERVICE_PRINCIPAL":
            raise FabricError("Not authenticated. Service Principal credentials are not configured or invalid in .env.", 401)
        raise FabricError("Not authenticated. Please sign in with your Microsoft Organization account first.", 401)
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def _get_odbc_driver():
    if not HAS_PYODBC:
        return "ODBC Driver 17 for SQL Server"
    drivers = pyodbc.drivers()
    for preferred in ["ODBC Driver 18 for SQL Server", "ODBC Driver 17 for SQL Server"]:
        if preferred in drivers:
            return preferred
    for d in drivers:
        if "SQL Server" in d:
            return d
    return "ODBC Driver 17 for SQL Server"


# --------------------------------------------------------------------------- #
# MetaData Database Operations (mssql-python / pyodbc + Entra Access Token)
# --------------------------------------------------------------------------- #
def get_metadata_db_connection(server=None, database=None):
    server = server or METADATA_SQL_ENDPOINT
    target_db = database or METADATA_DATABASE or "WH_MetaData"

    token = _get_sql_token()
    if not token:
        raise FabricError("Could not acquire access token for MetaData SQL Warehouse. Please check credentials in .env.", 401)

    token_as_bytes = bytes(token, "UTF-8")
    encoded_bytes = bytes(chain.from_iterable(zip(token_as_bytes, repeat(0))))
    token_bytes = struct.pack("<i", len(encoded_bytes)) + encoded_bytes

    def _connect(db):
        if HAS_MSSQL_PYTHON:
            conn_str = (
                f"Server={server},1433;"
                f"Database={db};"
                "Encrypt=Yes;"
                "TrustServerCertificate=Yes;"
            )
            return mssql_python.connect(conn_str, attrs_before={1256: token_bytes}, timeout=30)
        elif HAS_PYODBC:
            driver = _get_odbc_driver()
            conn_str = (
                f"Driver={{{driver}}};"
                f"Server={server},1433;"
                f"Database={db};"
                "Encrypt=Yes;"
                "TrustServerCertificate=Yes;"
            )
            return pyodbc.connect(conn_str, attrs_before={1256: token_bytes}, timeout=30)
        else:
            raise FabricError(
                "Neither 'mssql-python' nor 'pyodbc' is installed. "
                "Please run: pip install mssql-python",
                500,
            )

    # 1. Try connecting directly to target_db
    try:
        return _connect(target_db)
    except Exception as primary_err:
        log.warning("Connection to database '%s' failed: %s. Attempting fallback discovery...", target_db, primary_err)
        # 2. If target_db didn't start with WH_, try f"WH_{target_db}"
        if not target_db.startswith("WH_"):
            try:
                c = _connect(f"WH_{target_db}")
                log.info("Connected successfully using prefix WH_%s", target_db)
                return c
            except Exception:
                pass
        # 3. Fallback to connecting to master and discovering database name
        try:
            m_conn = _connect("master")
            cur = m_conn.cursor()
            cur.execute("SELECT name FROM sys.databases WHERE name NOT IN ('master', 'tempdb', 'model', 'msdb')")
            dbs = [row[0] for row in cur.fetchall()]
            cur.close()
            m_conn.close()

            matched = None
            for d in dbs:
                if d.lower() == target_db.lower() or d.lower() == f"wh_{target_db.lower()}":
                    matched = d
                    break
            if not matched and len(dbs) == 1:
                matched = dbs[0]

            if matched:
                log.info("Discovered warehouse database '%s' on server '%s'", matched, server)
                return _connect(matched)
        except Exception as discovery_err:
            log.warning("Database discovery via master failed: %s", discovery_err)

        raise primary_err


def insert_metadata_records(
    partner_id: int,
    workspace_id: str,
    workspace_name: str,
    warehouse_id: str,
    warehouse_name: str,
    connection_string: str = "",
    partner_name: str = "",
    staging_schema: str = "stg",
    schema_name: str = "dbo",
    semantic_model_name: str = "",
    semantic_model_id: str = "",
    semantic_model_tables: str = "",
    watermark_value: str = "1990-01-01 00:00:00.000000",
    server: str = None,
    database: str = None,
):
    """
    Inserts newly provisioned workspace and warehouse details into MetaData:
      1. Inserts into [Partner].[PartnerMaster]
      2. Reads all TableId and filter details from [Partner].[TableDefinition]
      3. Gets MAX(Id) from [Partner].[ConfigMaster]
      4. Inserts a row into [Partner].[ConfigMaster] for each TableId with watermark '1990-01-01 00:00:00.000000' (Jan 01 1990)
    """
    conn = get_metadata_db_connection(server, database)
    cursor = conn.cursor()
    try:
        # 1. Insert into [Partner].[PartnerMaster]
        insert_partner_sql = """
        INSERT INTO [Partner].[PartnerMaster] (
            [PartnerId],
            [PartnerName],
            [PartnerWarehouseName],
            [PartnerStagingSchema],
            [PartnerSchemaName],
            [PartnerConnectionString],
            [PartnerWarehouseId],
            [PartnerWorkspaceId],
            [PartnerSemanticModelName],
            [PartnerWorkspaceName],
            [PartnerSemanticModelId],
            [SemanticModelTables]
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """
        cursor.execute(
            insert_partner_sql,
            (
                partner_id,
                partner_name,
                warehouse_name,
                staging_schema,
                schema_name,
                connection_string,
                warehouse_id,
                workspace_id,
                semantic_model_name or None,
                workspace_name,
                semantic_model_id or None,
                semantic_model_tables or None,
            ),
        )
        log.info("Inserted PartnerMaster record for PartnerId=%s (%s)", partner_id, partner_name)

        # 2. Get all tables and their watermark metadata from [Partner].[TableDefinition]
        cursor.execute("SELECT [TableId], [WaterMarkField], [FilterType] FROM [Partner].[TableDefinition] WHERE [TableId] IS NOT NULL")
        table_rows = cursor.fetchall()
        log.info("Retrieved %d table(s) from [Partner].[TableDefinition]", len(table_rows))

        # 3. Get max ID from [Partner].[ConfigMaster]
        cursor.execute("SELECT COALESCE(MAX([Id]), 0) FROM [Partner].[ConfigMaster]")
        max_row = cursor.fetchone()
        current_max_id = max_row[0] if max_row and max_row[0] is not None else 0

        # 4. Insert into [Partner].[ConfigMaster] for each TableId with watermark (Jan 01 1990) and IsActive 1
        insert_config_sql = """
        INSERT INTO [Partner].[ConfigMaster] (
            [Id],
            [PartnerId],
            [TableId],
            [WaterMarkValue],
            [IsActive]
        ) VALUES (?, ?, ?, ?, ?)
        """
        inserted_configs = 0
        for row in table_rows:
            tid = row[0]
            wm_field = row[1]
            filter_type = (row[2] or "").lower()

            # Align with reference patterns:
            # - If no watermark field, set to NULL (e.g. full-load tables like Product)
            # - If integer watermark, set to '0' (e.g. SalesOrderLineKey)
            # - If DateTime watermark, set to Jan 01 1990 ('1990-01-01 00:00:00.000000')
            if not wm_field:
                row_wm = None
            elif "int" in filter_type:
                row_wm = "0"
            else:
                row_wm = watermark_value

            current_max_id += 1
            cursor.execute(insert_config_sql, (current_max_id, partner_id, tid, row_wm, 1))
            inserted_configs += 1

        conn.commit()
        log.info("Committed %d ConfigMaster records for PartnerId=%s (watermark=%s)", inserted_configs, partner_id, watermark_value)

        return {
            "partnerMasterInserted": True,
            "partnerId": partner_id,
            "partnerName": partner_name,
            "tablesFound": len(table_rows),
            "configMasterInserted": inserted_configs,
            "watermarkValue": watermark_value,
        }
    except Exception as e:
        try:
            conn.rollback()
        except Exception:
            pass
        log.exception("Error writing records to MetaData warehouse: %s", e)
        raise FabricError(f"Database error writing to MetaData warehouse: {e}") from e
    finally:
        try:
            cursor.close()
        except Exception:
            pass
        try:
            conn.close()
        except Exception:
            pass


# --------------------------------------------------------------------------- #
# HTTP helpers
# --------------------------------------------------------------------------- #
class FabricError(Exception):
    def __init__(self, message, status=None, details=None):
        super().__init__(message)
        self.status = status
        self.details = details


def _raise_for(resp, action):
    try:
        body = resp.json()
    except ValueError:
        body = resp.text
    if isinstance(body, dict):
        msg = body.get("message") or body.get("error", {}).get("message") or str(body)
        code = body.get("errorCode", "")
        msg = f"{code}: {msg}" if code else msg
    else:
        msg = str(body)[:500]
    raise FabricError(f"{action} failed (HTTP {resp.status_code}) - {msg}", resp.status_code, body)


def _call(method, url, action, json_body=None, max_retries=5):
    """Request with 429 / transient 5xx retry honoring Retry-After."""
    for attempt in range(max_retries):
        resp = requests.request(method, url, headers=_headers(), json=json_body, timeout=60)
        if resp.status_code == 429 or resp.status_code >= 500:
            wait = int(resp.headers.get("Retry-After", 2 ** attempt * 5))
            log.warning("%s: HTTP %s, retrying in %ss", action, resp.status_code, wait)
            time.sleep(wait)
            continue
        if resp.status_code >= 400:
            _raise_for(resp, action)
        return resp
    _raise_for(resp, action)


def _wait_for_lro(resp, action):
    """Poll a Fabric long-running operation (HTTP 202) until it finishes."""
    op_url = resp.headers.get("Location")
    if not op_url:
        return None
    wait = int(resp.headers.get("Retry-After", 5))
    deadline = time.time() + LRO_TIMEOUT_SECONDS

    while time.time() < deadline:
        time.sleep(wait)
        r = _call("GET", op_url, f"{action} (status poll)")
        body = r.json() if r.content else {}
        status = body.get("status")
        log.info("%s: operation status = %s", action, status)

        if status == "Succeeded":
            result_url = r.headers.get("Location") or op_url.rstrip("/") + "/result"
            rr = requests.get(result_url, headers=_headers(), timeout=60)
            if rr.ok and rr.content:
                try:
                    return rr.json()
                except ValueError:
                    pass
            return body
        if status in ("Failed", "Cancelled"):
            err = body.get("error") or {}
            raise FabricError(f"{action} {status.lower()} - {err.get('message', body)}", details=body)

        wait = int(r.headers.get("Retry-After", wait))

    raise FabricError(f"{action} timed out after {LRO_TIMEOUT_SECONDS}s")


# --------------------------------------------------------------------------- #
# Fabric operations
# --------------------------------------------------------------------------- #
def list_capacities():
    r = _call("GET", f"{FABRIC_API}/capacities", "List capacities")
    return r.json().get("value", [])


def get_workspace(workspace_id):
    r = _call("GET", f"{FABRIC_API}/workspaces/{workspace_id}", "Get workspace")
    return r.json()


def list_workspaces():
    url = f"{FABRIC_API}/workspaces"
    items = []
    while url:
        r = _call("GET", url, "List workspaces")
        data = r.json()
        items.extend(data.get("value", []))
        url = data.get("continuationUri")
    items.sort(key=lambda w: (w.get("displayName") or "").lower())
    return items


def create_workspace(name, description=""):
    r = _call("POST", f"{FABRIC_API}/workspaces", "Create workspace",
              {"displayName": name, "description": description})
    return r.json()


def assign_capacity(workspace_id, capacity_id):
    r = _call("POST", f"{FABRIC_API}/workspaces/{workspace_id}/assignToCapacity",
              "Assign capacity", {"capacityId": capacity_id})
    if r.status_code == 202:
        _wait_for_lro(r, "Assign capacity")
    _wait_for_capacity_assignment(workspace_id, capacity_id)


def _wait_for_capacity_assignment(workspace_id, capacity_id):
    """Workspace reports capacityAssignmentProgress; wait for 'Completed'."""
    deadline = time.time() + LRO_TIMEOUT_SECONDS
    while time.time() < deadline:
        ws = _call("GET", f"{FABRIC_API}/workspaces/{workspace_id}", "Get workspace").json()
        progress = ws.get("capacityAssignmentProgress", "Completed")
        if progress == "Completed" and ws.get("capacityId", "").lower() == capacity_id.lower():
            return ws
        if progress == "Failed":
            raise FabricError("Capacity assignment failed - check capacity state and permissions")
        time.sleep(5)
    raise FabricError("Timed out waiting for capacity assignment to complete")


def add_workspace_admin(workspace_id, principal_id_or_email, principal_type="User"):
    ident = (principal_id_or_email or "").strip()
    ptype = principal_type or "User"
    name = ident
    if ident and not GUID_RE.match(ident):
        ident, ptype, name = resolve_principal_to_guid(ident, ptype)
    _call("POST", f"{FABRIC_API}/workspaces/{workspace_id}/roleAssignments",
          f"Add workspace admin ({name or ident})",
          {"principal": {"id": ident, "type": ptype}, "role": "Admin"})


def create_warehouse(workspace_id, name, description=""):
    r = _call("POST", f"{FABRIC_API}/workspaces/{workspace_id}/warehouses",
              "Create warehouse", {"displayName": name, "description": description})
    if r.status_code == 202:
        return _wait_for_lro(r, "Create warehouse") or {}
    return r.json()


def delete_workspace(workspace_id):
    _call("DELETE", f"{FABRIC_API}/workspaces/{workspace_id}", "Delete workspace")


# --------------------------------------------------------------------------- #
# Web Authentication Routes (Standard OAuth 2.0 Web Flow)
# --------------------------------------------------------------------------- #
@app.get("/login")
def login_route():
    try:
        redirect_uri = f"http://{request.host}"
        msal_app = _get_msal_app()
        flow = msal_app.initiate_auth_code_flow(
            FABRIC_SCOPES,
            redirect_uri=redirect_uri,
            prompt="select_account",
        )
        if "auth_uri" not in flow:
            raise RuntimeError("Failed to begin Microsoft auth flow: " + str(flow))
        _auth_flows[flow["state"]] = flow
        log.info("Redirecting browser to Microsoft Organization Sign-In (redirect_uri=%s)", redirect_uri)
        return redirect(flow["auth_uri"])
    except Exception as e:
        log.exception("Login flow error")
        return f"""
        <!doctype html>
        <html>
        <head><title>Sign-In Error</title><style>body {{ font-family: Segoe UI, sans-serif; padding: 40px; background: #fff5f5; color: #991b1b; }}</style></head>
        <body>
          <h2>Sign-In Error</h2>
          <p>{e}</p>
          <p><a href="/" style="color:#117865; font-weight:bold;">← Return to Home</a></p>
        </body>
        </html>
        """, 500


@app.get("/logout")
def logout_route():
    try:
        msal_app = _get_msal_app()
        for account in msal_app.get_accounts():
            msal_app.remove_account(account)
        _save_cache()
        if os.path.exists(CACHE_FILE):
            try:
                os.remove(CACHE_FILE)
            except Exception:
                pass
    except Exception as e:
        log.warning("Logout error: %s", e)
    return redirect("/")


@app.post("/api/auth/sp-connect")
def api_auth_sp_connect():
    data = request.get_json(force=True) or {}
    tenant_id = (data.get("tenantId") or "").strip()
    client_id = (data.get("clientId") or "").strip()
    client_secret = (data.get("clientSecret") or "").strip()
    save_to_env = bool(data.get("saveToEnv", True))

    errors = []
    if not tenant_id:
        errors.append("Tenant ID is required.")
    if not client_id:
        errors.append("Client ID is required.")
    if not client_secret:
        errors.append("Client Secret is required.")
    if tenant_id and tenant_id.lower() in ("organizations", "common", "consumers"):
        errors.append("Tenant ID must be a specific Azure Directory (Tenant) ID GUID, not 'organizations'.")

    if errors:
        return jsonify({"ok": False, "error": " ".join(errors)}), 400

    try:
        test_cred = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
        )
        token_obj = test_cred.get_token(FABRIC_SCOPE)
        claims = _decode_token_claims(token_obj.token)
        app_name = claims.get("app_displayname") or "Azure Entra App"
        oid = claims.get("oid") or ""
    except Exception as e:
        log.exception("Validation of provided Service Principal credentials failed")
        return jsonify({
            "ok": False,
            "error": f"Failed to authenticate with Azure Entra: {e}"
        }), 400

    session["sp_credentials"] = {
        "tenant_id": tenant_id,
        "client_id": client_id,
        "client_secret": client_secret,
    }

    if save_to_env:
        try:
            _update_env_file(tenant_id, client_id, client_secret)
        except Exception as se:
            log.warning("Could not persist credentials to .env: %s", se)

    os.environ["AUTH_MODE"] = "SERVICE_PRINCIPAL"
    os.environ["AZURE_TENANT_ID"] = tenant_id
    os.environ["AZURE_CLIENT_ID"] = client_id
    os.environ["AZURE_CLIENT_SECRET"] = client_secret

    global _sp_credential, _sp_config_key
    _sp_credential = test_cred
    _sp_config_key = (tenant_id, client_id, client_secret)

    masked_client = f"{client_id[:8]}-****-****-****-{client_id[-4:]}" if len(client_id) > 12 else client_id
    return jsonify({
        "ok": True,
        "message": f"Service Principal '{app_name}' connected successfully!",
        "user": {
            "name": f"Service Principal ({app_name})",
            "email": f"App ID: {masked_client}",
            "clientId": client_id,
            "oid": oid,
            "tid": tenant_id,
        }
    })


@app.post("/api/auth/sp-disconnect")
def api_auth_sp_disconnect():
    session.pop("sp_credentials", None)
    global _sp_credential, _sp_config_key
    _sp_credential = None
    _sp_config_key = None
    return jsonify({"ok": True, "message": "Service Principal disconnected from session."})


@app.get("/api/auth/status")
def api_auth_status():
    auth_mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()

    if auth_mode == "SERVICE_PRINCIPAL":
        tenant, client_id, client_secret = _get_sp_credentials_from_context()

        missing = []
        if not tenant:
            missing.append("Tenant ID")
        if not client_id:
            missing.append("Client ID")
        if not client_secret:
            missing.append("Client Secret")

        if missing:
            return jsonify({
                "authenticated": False,
                "authMode": "SERVICE_PRINCIPAL",
                "error": f"Please provide Service Principal details: {', '.join(missing)}.",
                "missing": missing,
                "tenantId": tenant or "008502d6-3f79-46f0-ab37-9354e3fe80ff",
                "clientId": client_id or "",
            })

        if tenant.lower() in ("organizations", "common", "consumers"):
            return jsonify({
                "authenticated": False,
                "authMode": "SERVICE_PRINCIPAL",
                "error": f"Tenant ID cannot be '{tenant}'. Please specify your actual Azure Directory (Tenant) ID GUID.",
                "tenantId": tenant,
                "clientId": client_id,
            })

        try:
            token = _get_access_token()
            claims = _decode_token_claims(token) if token else {}
            masked_client = f"{client_id[:8]}-****-****-****-{client_id[-4:]}" if len(client_id) > 12 else client_id
            app_name = claims.get("app_displayname") or "Azure Entra App"
            oid = claims.get("oid") or ""
            return jsonify({
                "authenticated": True,
                "authMode": "SERVICE_PRINCIPAL",
                "user": {
                    "name": f"Service Principal ({app_name})",
                    "email": f"App ID: {masked_client}",
                    "clientId": client_id,
                    "oid": oid,
                    "tid": tenant,
                },
                "tenantId": tenant,
                "clientId": client_id,
                "capacityId": (os.getenv("FABRIC_CAPACITY_ID") or os.getenv("CAPACITY_ID") or "").strip() or DEFAULT_CAPACITY_ID,
            })
        except Exception as e:
            return jsonify({
                "authenticated": False,
                "authMode": "SERVICE_PRINCIPAL",
                "error": str(e),
                "tenantId": tenant,
                "clientId": client_id,
            })

    # Interactive flow fallback
    try:
        msal_app = _get_msal_app()
        accounts = msal_app.get_accounts()
        if not accounts:
            return jsonify({"authenticated": False, "authMode": "INTERACTIVE"})

        result = msal_app.acquire_token_silent(FABRIC_SCOPES, account=accounts[0])
        if result and "access_token" in result:
            _save_cache()
            claims = result.get("id_token_claims") or _decode_token_claims(result["access_token"])
            return jsonify({
                "authenticated": True,
                "authMode": "INTERACTIVE",
                "user": {
                    "name": claims.get("name") or claims.get("unique_name") or accounts[0].get("username") or "Organization User",
                    "email": claims.get("preferred_username") or claims.get("upn") or accounts[0].get("username") or "",
                    "oid": claims.get("oid") or "",
                    "tid": claims.get("tid") or "",
                },
            })
        return jsonify({"authenticated": False, "authMode": "INTERACTIVE"})
    except Exception as e:
        return jsonify({"authenticated": False, "authMode": "INTERACTIVE", "error": str(e)})


@app.get("/api/test-db")
def api_test_db():
    """Validates connectivity to the MetaData Warehouse using current credentials."""
    try:
        t0 = time.time()
        conn = get_metadata_db_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()

        table_count = None
        try:
            cursor.execute("SELECT COUNT(*) FROM [Partner].[TableDefinition]")
            row = cursor.fetchone()
            table_count = row[0] if row else 0
        except Exception:
            pass

        cursor.close()
        conn.close()
        elapsed = round(time.time() - t0, 2)
        return jsonify({
            "ok": True,
            "database": METADATA_DATABASE,
            "server": METADATA_SQL_ENDPOINT,
            "seconds": elapsed,
            "tableDefinitionCount": table_count,
            "message": f"Successfully connected to MetaData Warehouse '{METADATA_DATABASE}' ({elapsed}s) using Service Principal.",
        })
    except Exception as e:
        log.exception("Database connectivity test failed")
        return jsonify({"ok": False, "error": str(e)}), 500


# --------------------------------------------------------------------------- #
# Application Routes
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    if "code" in request.args:
        try:
            state = request.args.get("state")
            flow = _auth_flows.pop(state, None)
            if flow:
                msal_app = _get_msal_app()
                result = msal_app.acquire_token_by_auth_code_flow(flow, request.args)
                if "access_token" in result:
                    _save_cache()
                    claims = result.get("id_token_claims") or _decode_token_claims(result["access_token"])
                    username = claims.get("name") or claims.get("preferred_username") or "Organization User"
                    log.info("Successfully signed in organization account: %s", username)
                    return redirect("/")
                else:
                    err = result.get("error_description") or result.get("error") or str(result)
                    log.error("Token acquisition by auth code failed: %s", err)
                    return f"""
                    <!doctype html>
                    <html>
                    <head><title>Sign-in Failed</title><style>body {{ font-family: Segoe UI, sans-serif; padding: 40px; background: #fff5f5; color: #991b1b; }}</style></head>
                    <body>
                      <h2>Microsoft Organization Sign-In Failed</h2>
                      <p>{err}</p>
                      <p><a href="/login" style="color:#117865; font-weight:bold;">Retry Sign-In</a></p>
                    </body>
                    </html>
                    """, 400
            else:
                log.warning("No matching auth flow for state '%s', redirecting to clean home.", state)
                return redirect("/")
        except Exception as e:
            log.exception("Auth redirect handling error")
            return f"""
            <!doctype html>
            <html>
            <head><title>Auth Error</title><style>body {{ font-family: Segoe UI, sans-serif; padding: 40px; background: #fff5f5; color: #991b1b; }}</style></head>
            <body>
              <h2>Authentication Error</h2>
              <p>{e}</p>
              <p><a href="/" style="color:#117865; font-weight:bold;">← Return to Home</a></p>
            </body>
            </html>
            """, 500

    return render_template("index.html")


@app.get("/api/capacities")
def api_capacities():
    try:
        caps = list_capacities()
        return jsonify([
            {"id": c["id"], "name": c.get("displayName"), "sku": c.get("sku"),
             "region": c.get("region"), "state": c.get("state")}
            for c in caps
        ])
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)}), 500


@app.get("/api/workspaces")
def api_workspaces():
    try:
        workspaces = list_workspaces()
        return jsonify([
            {
                "id": ws["id"],
                "name": ws.get("displayName") or ws["id"],
                "description": ws.get("description", ""),
                "type": ws.get("type", "Workspace"),
                "capacityId": ws.get("capacityId", ""),
            }
            for ws in workspaces
        ])
    except Exception as e:  # noqa: BLE001
        return jsonify({"error": str(e)}), 500


@app.get("/api/resolve-principal")
def api_resolve_principal():
    query = (request.args.get("q") or "").strip()
    if not query:
        return jsonify({"ok": False, "error": "Query parameter 'q' is required."}), 400
    try:
        oid, ptype, name = resolve_principal_to_guid(query)
        return jsonify({"ok": True, "id": oid, "type": ptype, "name": name, "query": query})
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.post("/api/provision")
def api_provision():
    data = request.get_json(force=True) or {}
    sp_tenant = (data.get("spTenantId") or "").strip()
    sp_client = (data.get("spClientId") or "").strip()
    sp_secret = (data.get("spClientSecret") or "").strip()
    if sp_tenant and sp_client and sp_secret:
        session["sp_credentials"] = {
            "tenant_id": sp_tenant,
            "client_id": sp_client,
            "client_secret": sp_secret,
        }
        global _sp_credential, _sp_config_key
        key = (sp_tenant, sp_client, sp_secret)
        if _sp_credential is None or _sp_config_key != key:
            _sp_credential = ClientSecretCredential(
                tenant_id=sp_tenant,
                client_id=sp_client,
                client_secret=sp_secret,
            )
            _sp_config_key = key

    capacity_id = (data.get("capacityId") or "").strip()
    is_existing_workspace = bool(data.get("isExistingWorkspace", True))
    workspace_id_input = (data.get("workspaceId") or "").strip()
    ws_name = (data.get("workspaceName") or "").strip()
    wh_name = (data.get("warehouseName") or "").strip()
    description = (data.get("description") or "").strip()
    admin_id = (data.get("adminObjectId") or "").strip()
    admin_type = data.get("adminType") or "User"
    rollback = bool(data.get("rollbackOnFailure"))

    # Partner metadata parameters
    partner_id_raw = data.get("partnerId")
    partner_name = (data.get("partnerName") or "").strip()
    watermark_val = (data.get("watermarkValue") or "").strip() or "1990-01-01 00:00:00.000000"
    partner_staging_schema = (data.get("partnerStagingSchema") or "stg").strip()
    partner_schema_name = (data.get("partnerSchemaName") or "dbo").strip()
    meta_sql_endpoint = (data.get("metadataSqlEndpoint") or "").strip() or None
    meta_database = (data.get("metadataDatabase") or "").strip() or None

    # ---- validation
    errors = []
    if not GUID_RE.match(capacity_id):
        errors.append("Capacity ID must be a GUID.")
    if is_existing_workspace:
        if not workspace_id_input or not GUID_RE.match(workspace_id_input):
            errors.append("Please select a valid existing workspace.")
    else:
        if not ws_name or len(ws_name) > 256:
            errors.append("Workspace name is required (max 256 chars).")
    if not wh_name or len(wh_name) > 256:
        errors.append("Warehouse name is required (max 256 chars).")
    # Admin identifier can be either an Entra Object GUID or an email address / UPN
    resolved_admin_id = None
    resolved_admin_type = admin_type
    resolved_admin_name = ""
    if admin_id:
        if GUID_RE.match(admin_id):
            resolved_admin_id = admin_id
            resolved_admin_name = admin_id
        else:
            try:
                resolved_admin_id, resolved_admin_type, resolved_admin_name = resolve_principal_to_guid(admin_id, admin_type)
            except Exception as e:
                errors.append(f"Admin principal resolution error: {e}")

    # Validate Partner ID (compulsory)
    partner_id = None
    if partner_id_raw is None or str(partner_id_raw).strip() == "":
        errors.append("Partner ID is required.")
    else:
        try:
            partner_id = int(partner_id_raw)
        except (ValueError, TypeError):
            errors.append("Partner ID must be a valid integer.")

    # Validate Partner Name (compulsory)
    if not partner_name:
        errors.append("Partner Name is required.")
    elif len(partner_name) > 200:
        errors.append("Partner Name must not exceed 200 characters.")

    if errors:
        return jsonify({"ok": False, "steps": [], "error": " ".join(errors)}), 400

    steps, workspace_id = [], None

    def step(name, fn):
        t0 = time.time()
        result = fn()
        steps.append({"step": name, "status": "done", "seconds": round(time.time() - t0, 1)})
        return result

    try:
        # Step 1: Workspace setup
        if is_existing_workspace:
            ws = step(f"Select existing workspace ({ws_name or workspace_id_input})", lambda: get_workspace(workspace_id_input))
            workspace_id = ws["id"]
            if not ws_name:
                ws_name = ws.get("displayName") or workspace_id
        else:
            ws = step(f"Create workspace ({ws_name})", lambda: create_workspace(ws_name, description))
            workspace_id = ws["id"]

        # Step 2: Assign or verify capacity
        ws_cap = (ws.get("capacityId") or "").strip()
        if not ws_cap or ws_cap.lower() != capacity_id.lower():
            step("Assign capacity", lambda: assign_capacity(workspace_id, capacity_id))
        else:
            steps.append({"step": "Capacity verified", "status": "done", "seconds": 0.0})

        # Step 3: Optional admin
        if resolved_admin_id:
            label = f"Add workspace admin ({resolved_admin_name})" if resolved_admin_name and resolved_admin_name != resolved_admin_id else "Add workspace admin"
            step(label, lambda: add_workspace_admin(workspace_id, resolved_admin_id, resolved_admin_type))

        # Step 4: Create warehouse
        wh = step("Create warehouse", lambda: create_warehouse(workspace_id, wh_name, description))
        wh_id = wh.get("id") or ""
        conn_str = (wh.get("properties") or {}).get("connectionString") or ""
        if not conn_str and wh_id:
            try:
                wh_details = _call("GET", f"{FABRIC_API}/workspaces/{workspace_id}/warehouses/{wh_id}", "Get warehouse details").json()
                conn_str = (wh_details.get("properties") or {}).get("connectionString") or ""
            except Exception:
                pass
        if not conn_str and wh_id:
            conn_str = f"{wh_id}.datawarehouse.fabric.microsoft.com"

        # Step 5: Insert records into MetaData tables
        meta_result = step(
            "Insert MetaData records (PartnerMaster & ConfigMaster)",
            lambda: insert_metadata_records(
                partner_id=partner_id,
                workspace_id=workspace_id,
                workspace_name=ws_name,
                warehouse_id=wh_id,
                warehouse_name=wh_name,
                connection_string=conn_str,
                partner_name=partner_name,
                staging_schema=partner_staging_schema,
                schema_name=partner_schema_name,
                watermark_value=watermark_val,
                server=meta_sql_endpoint,
                database=meta_database,
            ),
        )

        return jsonify({
            "ok": True,
            "steps": steps,
            "workspace": {
                "id": workspace_id,
                "name": ws_name,
                "capacityId": capacity_id,
                "url": f"https://app.fabric.microsoft.com/groups/{workspace_id}",
            },
            "warehouse": {
                "id": wh_id,
                "name": wh.get("displayName", wh_name),
                "connectionString": conn_str,
            },
            "metaData": meta_result,
        })

    except Exception as e:  # noqa: BLE001
        log.exception("Provisioning failed")
        steps.append({"step": "error", "status": "failed", "message": str(e)})
        rolled_back = False
        if rollback and workspace_id and not is_existing_workspace:
            try:
                delete_workspace(workspace_id)
                rolled_back = True
            except Exception as de:  # noqa: BLE001
                steps.append({"step": "rollback", "status": "failed", "message": str(de)})
        return jsonify({
            "ok": False,
            "steps": steps,
            "error": str(e),
            "workspaceId": None if rolled_back else workspace_id,
            "rolledBack": rolled_back,
        }), 500


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.getenv("PORT", "5000")), debug=False, threaded=True)
