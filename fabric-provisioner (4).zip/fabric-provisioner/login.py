"""
Diagnostic & Verification CLI script for Microsoft Fabric Provisioner.
Tests Service Principal authentication for:
  1. Microsoft Fabric REST API (workspace & capacity management)
  2. Microsoft Fabric MetaData Warehouse SQL endpoint (Partner & Config tables)
"""

import base64
import json
import os
import struct
import sys
import time
from itertools import chain, repeat
from dotenv import load_dotenv

load_dotenv()

FABRIC_SCOPE = "https://api.fabric.microsoft.com/.default"
SQL_SCOPE = "https://database.windows.net/.default"
FABRIC_API = "https://api.fabric.microsoft.com/v1"


def decode_token_claims(token_str: str) -> dict:
    try:
        parts = token_str.split(".")
        if len(parts) >= 2:
            payload = parts[1]
            rem = len(payload) % 4
            if rem > 0:
                payload += "=" * (4 - rem)
            return json.loads(base64.urlsafe_b64decode(payload.encode("utf-8")))
    except Exception:
        pass
    return {}


def test_service_principal():
    from azure.identity import ClientSecretCredential
    import requests

    tenant = (os.getenv("AZURE_TENANT_ID") or os.getenv("FABRIC_TENANT_ID") or "").strip() or "008502d6-3f79-46f0-ab37-9354e3fe80ff"
    client_id = (os.getenv("AZURE_CLIENT_ID") or os.getenv("FABRIC_CLIENT_ID") or "").strip() or "25ad11d7-5885-4f0e-8424-919bf02e04eb"
    client_secret = (os.getenv("AZURE_CLIENT_SECRET") or os.getenv("FABRIC_CLIENT_SECRET") or "").strip() or "SWE8Q~EtZhXJAxLm_mVlLFBSI~It5ljFjID~kbvn"
    meta_server = os.getenv("METADATA_SQL_ENDPOINT", "2ybikadzh7yenkzxsnkoh7ua74-3umgq6mqhwfuhesadoaslzi5ei.datawarehouse.fabric.microsoft.com")
    meta_db = os.getenv("METADATA_DATABASE", "WH_MetaData")

    print("\n" + "=" * 70, flush=True)
    print(" MICROSOFT FABRIC - SERVICE PRINCIPAL AUTHENTICATION TEST", flush=True)
    print("=" * 70, flush=True)
    print(f" Tenant ID:       {tenant or '[NOT SET IN .env]'}", flush=True)
    print(f" Client ID:       {client_id or '[NOT SET IN .env]'}", flush=True)
    print(f" Client Secret:   {'*' * 8 if client_secret else '[NOT SET IN .env]'}", flush=True)
    print(f" MetaData Server: {meta_server}", flush=True)
    print(f" MetaData DB:     {meta_db}", flush=True)
    print("-" * 70, flush=True)

    missing = []
    if not tenant:
        missing.append("AZURE_TENANT_ID")
    if not client_id:
        missing.append("AZURE_CLIENT_ID")
    if not client_secret:
        missing.append("AZURE_CLIENT_SECRET")

    if missing:
        print(f"\n[ERROR] Missing required Service Principal configuration in .env: {', '.join(missing)}", file=sys.stderr)
        print("Please edit .env and configure these variables before running.", file=sys.stderr)
        print("=" * 70 + "\n", file=sys.stderr)
        sys.exit(1)

    if tenant.lower() in ("organizations", "common", "consumers"):
        print(f"\n[ERROR] AZURE_TENANT_ID cannot be '{tenant}' for Service Principal auth.", file=sys.stderr)
        print("Must be your actual Azure Directory (Tenant) ID GUID in .env.", file=sys.stderr)
        print("=" * 70 + "\n", file=sys.stderr)
        sys.exit(1)

    try:
        cred = ClientSecretCredential(
            tenant_id=tenant,
            client_id=client_id,
            client_secret=client_secret,
        )
    except Exception as e:
        print(f"\n[ERROR] Failed to instantiate ClientSecretCredential: {e}", file=sys.stderr)
        sys.exit(1)

    # 1. Test Fabric API Token
    print("\n[1/3] Acquiring Microsoft Fabric API token...", flush=True)
    t0 = time.time()
    try:
        fabric_token = cred.get_token(FABRIC_SCOPE).token
        claims = decode_token_claims(fabric_token)
        app_name = claims.get("app_displayname") or "Entra App"
        oid = claims.get("oid") or ""
        print(f"  [OK] Fabric token acquired in {round(time.time() - t0, 2)}s")
        print(f"       App: {app_name} | AppId: {claims.get('appid', client_id)}")
        if oid:
            print(f"       Service Principal Object ID: {oid}")
    except Exception as e:
        print(f"  [FAILED] Could not acquire Fabric API token: {e}", file=sys.stderr)
        print("\nTroubleshooting tips:", file=sys.stderr)
        print("  - Check that AZURE_CLIENT_ID and AZURE_CLIENT_SECRET are correct and not expired.", file=sys.stderr)
        print("  - Check that AZURE_TENANT_ID is the correct directory.", file=sys.stderr)
        sys.exit(1)

    # 2. Test Fabric REST API Access (Capacities & Workspaces)
    print("\n[2/3] Testing Fabric REST API connectivity (list capacities)...", flush=True)
    t0 = time.time()
    headers = {"Authorization": f"Bearer {fabric_token}", "Content-Type": "application/json"}
    try:
        r = requests.get(f"{FABRIC_API}/capacities", headers=headers, timeout=30)
        if r.status_code == 200:
            caps = r.json().get("value", [])
            print(f"  [OK] Successfully contacted Fabric API in {round(time.time() - t0, 2)}s")
            print(f"       Found {len(caps)} capacity/capacities available.")
            for c in caps:
                print(f"         - {c.get('displayName')} (ID: {c.get('id')}, SKU: {c.get('sku')}, State: {c.get('state')})")
        else:
            print(f"  [WARNING] Fabric API returned HTTP {r.status_code}: {r.text[:300]}")
            print("  Note: Ensure 'Service principals can use Fabric APIs' is enabled in the Microsoft Fabric Admin Portal.")
    except Exception as e:
        print(f"  [WARNING] Fabric API call failed: {e}")

    # 3. Test MetaData SQL Warehouse Connection
    print("\n[3/3] Testing SQL connection to MetaData Warehouse...", flush=True)
    t0 = time.time()
    try:
        sql_token = cred.get_token(SQL_SCOPE).token
        print(f"  [OK] SQL token acquired for {SQL_SCOPE} in {round(time.time() - t0, 2)}s")
    except Exception as e:
        print(f"  [FAILED] Could not acquire SQL token: {e}", file=sys.stderr)
        sys.exit(1)

    # Convert token to SQL_COPT_SS_ACCESS_TOKEN format
    token_as_bytes = bytes(sql_token, "UTF-8")
    encoded_bytes = bytes(chain.from_iterable(zip(token_as_bytes, repeat(0))))
    token_bytes = struct.pack("<i", len(encoded_bytes)) + encoded_bytes

    # Attempt connection
    conn = None
    try:
        try:
            import mssql_python
            conn_str = (
                f"Server={meta_server},1433;"
                f"Database={meta_db};"
                "Encrypt=Yes;"
                "TrustServerCertificate=Yes;"
            )
            print("  Connecting via mssql-python...", flush=True)
            conn = mssql_python.connect(conn_str, attrs_before={1256: token_bytes}, timeout=30)
        except ImportError:
            import pyodbc
            conn_str = (
                f"Driver={{ODBC Driver 17 for SQL Server}};"
                f"Server={meta_server},1433;"
                f"Database={meta_db};"
                "Encrypt=Yes;"
                "TrustServerCertificate=Yes;"
            )
            print("  Connecting via pyodbc...", flush=True)
            conn = pyodbc.connect(conn_str, attrs_before={1256: token_bytes}, timeout=30)

        cursor = conn.cursor()
        cursor.execute("SELECT 1")
        cursor.fetchone()
        print(f"  [OK] Connected to database '{meta_db}' successfully!")

        # Check TableDefinition count
        try:
            cursor.execute("SELECT COUNT(*) FROM [Partner].[TableDefinition]")
            t_count = cursor.fetchone()[0]
            print(f"       Found {t_count} table definitions in [Partner].[TableDefinition]")
        except Exception as qe:
            print(f"       Note: Could not query [Partner].[TableDefinition]: {qe}")

        cursor.close()
        conn.close()
    except Exception as dbe:
        print(f"  [FAILED] Database connection failed: {dbe}", file=sys.stderr)
        print("\nTroubleshooting tips for MetaData Warehouse:", file=sys.stderr)
        print("  - Ensure the Service Principal is added to the Fabric Workspace containing the MetaData Warehouse.", file=sys.stderr)
        print("  - Or grant the Service Principal SQL permissions on the warehouse database:", file=sys.stderr)
        print(f"    CREATE USER [{client_id}] FROM EXTERNAL PROVIDER;", file=sys.stderr)
        print(f"    ALTER ROLE db_owner ADD MEMBER [{client_id}];", file=sys.stderr)
        sys.exit(1)

    print("\n" + "=" * 70, flush=True)
    print(" ALL CHECKS PASSED! Service Principal is configured correctly.", flush=True)
    print(" You can start the web app with: python app.py", flush=True)
    print("=" * 70 + "\n", flush=True)


def test_interactive():
    from azure.identity import InteractiveBrowserCredential, TokenCachePersistenceOptions

    tenant = os.getenv("AZURE_TENANT_ID") or "organizations"
    print("=" * 68, flush=True)
    print(" MICROSOFT FABRIC - ORGANIZATION ACCOUNT INTERACTIVE SIGN-IN", flush=True)
    print("=" * 68, flush=True)

    cache_opts = None
    try:
        cache_opts = TokenCachePersistenceOptions()
    except Exception:
        pass

    kwargs = {"tenant_id": tenant, "prompt": "select_account"}
    if cache_opts:
        kwargs["cache_persistence_options"] = cache_opts

    cred = InteractiveBrowserCredential(**kwargs)
    try:
        token_obj = cred.get_token(FABRIC_SCOPE)
        claims = decode_token_claims(token_obj.token)
        name = claims.get("name") or "User"
        print(f"Signed in successfully as: {name}")
    except Exception as e:
        print(f"Interactive sign-in failed: {e}", file=sys.stderr)
        sys.exit(1)


def main():
    mode = os.getenv("AUTH_MODE", "SERVICE_PRINCIPAL").upper()
    if mode == "INTERACTIVE":
        test_interactive()
    else:
        test_service_principal()


if __name__ == "__main__":
    main()
